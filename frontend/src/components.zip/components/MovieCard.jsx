import React from 'react'
import { Poster_URL } from '../../utils/constant'
import { useDispatch } from 'react-redux';
import { getID, setOpen } from '../redux/moviesSlice';

const MovieCard = ({posterPath,movieId}) => {
  const dispatch = useDispatch()
  if (posterPath ===null) return null;
 
const handleOpen = () =>{
  dispatch(getID(movieId))
  dispatch(setOpen(true))
}

  return (
    <div className='w-48 ' onClick={handleOpen}>
  <img className="w-64 h-64" src={`${Poster_URL}/${posterPath}`} alt="wait " />
    </div>
  )
}

export default MovieCard