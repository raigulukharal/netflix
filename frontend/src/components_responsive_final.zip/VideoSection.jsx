import React from 'react';
import VideoBackground from './VideoBackground';
import VideoTitle from './VideoTitle';

const VideoSection = () => {
  return (
    <div className="w-full max-w-screen-lg mx-auto px-4 relative w-screen h-screen">
      <VideoBackground />
      <VideoTitle />
    </div>
  );
};

export default VideoSection;
